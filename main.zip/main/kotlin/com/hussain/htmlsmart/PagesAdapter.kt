package com.hussain.htmlsmart

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class PagesAdapter(
    private var originalList: List<HTMLPage>,
    private val onItemClick: (HTMLPage) -> Unit,
    private val onItemLongClick: (HTMLPage) -> Unit
) : RecyclerView.Adapter<PagesAdapter.ViewHolder>() {

    private var filteredList: MutableList<HTMLPage> = originalList.toMutableList()

    inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.text_view_title)
        val icon: ImageView = v.findViewById(R.id.image_view_icon)
        val card: CardView = v.findViewById(R.id.card_view)
        val root: View = v.findViewById(R.id.item_root)

        init {
            root.isFocusable = true
            root.isFocusableInTouchMode = true
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_page, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val page = filteredList[position]
        holder.title.text = page.title

        if (!page.iconUri.isNullOrEmpty()) {
            try {
                holder.icon.setImageURI(Uri.parse(page.iconUri))
            } catch (_: Exception) {
                holder.icon.setImageResource(R.drawable.ic_code_black_24dp)
            }
        } else {
            holder.icon.setImageResource(R.drawable.ic_code_black_24dp)
        }

        val clickListener = View.OnClickListener {
            onItemClick(page)
        }
        
        val longClickListener = View.OnLongClickListener {
            onItemLongClick(page)
            true
        }

        holder.root.setOnClickListener(clickListener)
        holder.card.setOnClickListener(clickListener)
        
        holder.root.setOnLongClickListener(longClickListener)
        holder.card.setOnLongClickListener(longClickListener)
    }

    override fun getItemCount() = filteredList.size

    fun updateList(newList: List<HTMLPage>) {
        originalList = newList
        filteredList = newList.toMutableList()
        notifyDataSetChanged()
    }

    fun filter(query: String) {
    // دالة مساعدة لتطنيش التشكيل والهمزات والتاء المربوطة
    fun normalizeText(text: String): String {
        return text
            // إزالة التشكيل (الحركات)
            .replace(Regex("[\\u064B-\\u0652]"), "")
            // توحيد أشكال الهمزات
            .replace(Regex("[أإآءئؤ]"), "ا")
            // توحيد التاء المربوطة والهاء
            .replace('ة', 'ه')
            // توحيد الألف المقصورة والياء
            .replace('ى', 'ي')
            .lowercase()
            .trim()
    }

    val cleanQuery = normalizeText(query)

    filteredList = if (cleanQuery.isEmpty()) {
        originalList.toMutableList()
    } else {
        originalList.filter { 
            normalizeText(it.title).contains(cleanQuery) 
        }.toMutableList()
    }
    notifyDataSetChanged()
}

}