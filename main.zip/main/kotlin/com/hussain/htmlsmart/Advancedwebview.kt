package com.hussain.htmlsmart

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.AttributeSet
import android.util.Base64
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

@SuppressLint("SetJavaScriptEnabled")
class AdvancedWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var filePathCallback: ValueCallback<Array<Uri>>? = null

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    init {
        setupWebView()
    }

    @Suppress("DEPRECATION")
    private fun setupWebView() {
        isFocusable = true
        isFocusableInTouchMode = true

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true

            mediaPlaybackRequiresUserGesture = false

            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }

            loadWithOverviewMode = true
            useWideViewPort = true
            defaultTextEncodingName = "UTF-8"
            textZoom = 140
        }

        setInitialScale(0)

        setDownloadListener { url, _, _, mimetype, _ ->
            try {
                var bytes: ByteArray? = null
                val cleanMimeType = mimetype ?: "application/octet-stream"
                val fileName = when {
                    cleanMimeType.contains("epub") -> "clean_edited_book.epub"
                    cleanMimeType.contains("pdf") -> "document.pdf"
                    cleanMimeType.contains("zip") -> "archive.zip"
                    else -> "downloaded_file.bin"
                }

                if (url.startsWith("data:")) {
                    val base64Data = url.substringAfter(",")
                    bytes = Base64.decode(base64Data, Base64.DEFAULT)
                } else if (url.startsWith("blob:")) {
                    return@setDownloadListener
                }

                bytes?.let { decodedBytes ->
                    val activity = context as? MainActivity ?: return@setDownloadListener
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val resolver = activity.contentResolver
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(MediaStore.MediaColumns.MIME_TYPE, cleanMimeType)
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            resolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(decodedBytes)
                            }
                            Toast.makeText(activity, "✅ تم حفظ الملف في التنزيلات: $fileName", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        if (!downloadsDir.exists()) downloadsDir.mkdirs()
                        val file = File(downloadsDir, fileName)
                        FileOutputStream(file).use { it.write(decodedBytes) }
                        Toast.makeText(activity, "✅ تم حفظ الملف في التنزيلات", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "❌ خطأ في التحميل: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        webChromeClient = object : WebChromeClient() {

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    onHideCustomView()
                    return
                }
                customView = view
                customViewCallback = callback
                (context as? MainActivity)?.toggleFullscreen(true, view)
            }

            override fun onHideCustomView() {
                (context as? MainActivity)?.toggleFullscreen(false, null)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@AdvancedWebView.filePathCallback?.onReceiveValue(null)
                this@AdvancedWebView.filePathCallback = filePathCallback

                val acceptTypes = fileChooserParams?.acceptTypes
                val isImagePicker = acceptTypes?.any { it.contains("image", ignoreCase = true) } == true

                val intent: Intent = if (isImagePicker) {
                    Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                        type = "image/*"
                    }
                } else {
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }

                try {
                    (context as MainActivity).startActivityForResult(intent, 1001)
                } catch (e: Exception) {
                    this@AdvancedWebView.filePathCallback?.onReceiveValue(null)
                    this@AdvancedWebView.filePathCallback = null
                    return false
                }
                return true
            }
        }
    }

    fun loadHtmlContent(html: String) {
        loadDataWithBaseURL("http://localhost/", html, "text/html; charset=UTF-8", "UTF-8", null)
    }
}