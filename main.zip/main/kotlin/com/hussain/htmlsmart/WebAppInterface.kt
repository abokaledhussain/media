package com.hussain.htmlsmart

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WebAppInterface(private val activity: MainActivity) {

    companion object {
        private const val PERMISSION_REQUEST_CODE = 1001
        private const val IMAGE_QUALITY = 100
    }

    @JavascriptInterface
    fun pickDirectory() {
        activity.runOnUiThread {
            @Suppress("DEPRECATION")
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            @Suppress("DEPRECATION")
            activity.startActivityForResult(intent, 4004)
        }
    }

    @JavascriptInterface
    fun shareText(text: String) {
        activity.runOnUiThread {
            try {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, text)
                    type = "text/plain"
                }
                val shareIntent = Intent.createChooser(sendIntent, "مشاركة الفائدة عبر:")
                activity.startActivity(shareIntent)
            } catch (e: Exception) {
                Toast.makeText(activity, "فشلت المشاركة: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun triggerPrint() {
        activity.runOnUiThread { activity.printCurrentPage() }
    }

    @JavascriptInterface
    fun printPage() {
        activity.runOnUiThread { activity.printCurrentPage() }
    }

    @JavascriptInterface
    fun shareBook(text: String) {
        shareText(text)
    }

    @JavascriptInterface
    fun saveFile(data: String, fileName: String) {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = activity.contentResolver
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    uri?.let {
                        resolver.openOutputStream(it)?.use { outputStream ->
                            outputStream.write(data.toByteArray())
                        }
                        Toast.makeText(activity, "✅ تم حفظ الملف في التنزيلات: $fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) downloadsDir.mkdirs()
                    val file = File(downloadsDir, fileName)
                    FileOutputStream(file).use { it.write(data.toByteArray()) }
                    Toast.makeText(activity, "✅ تم حفظ الملف في التنزيلات", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(activity, "❌ خطأ في الحفظ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // دالة حفظ الملفات الثنائية (مثل ePub والـ ZIP) المحدثة خصيصاً لتحرير الكتب
    @JavascriptInterface
    fun saveBinaryFile(base64Data: String, fileName: String, mimeType: String) {
        activity.runOnUiThread {
            try {
                var cleanBase64 = base64Data
                if (base64Data.contains(",")) {
                    cleanBase64 = base64Data.substring(base64Data.indexOf(",") + 1)
                }

                val fileBytes = Base64.decode(cleanBase64, Base64.DEFAULT)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = activity.contentResolver
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    uri?.let {
                        resolver.openOutputStream(it)?.use { outputStream ->
                            outputStream.write(fileBytes)
                        }
                        Toast.makeText(activity, "✅ تم حفظ ملف ePub في التنزيلات: $fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) downloadsDir.mkdirs()
                    val file = File(downloadsDir, fileName)
                    FileOutputStream(file).use { it.write(fileBytes) }
                    Toast.makeText(activity, "✅ تم حفظ ملف ePub في التنزيلات", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(activity, "❌ خطأ في حفظ الملف: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun pickFile() {
        activity.runOnUiThread {
            try {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "application/json"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                @Suppress("DEPRECATION")
                activity.startActivityForResult(Intent.createChooser(intent, "اختر ملف البيانات (JSON)"), 3003)
            } catch (e: Exception) {
                Toast.makeText(activity, "❌ فشل فتح مدير الملفات: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun saveImage(base64Data: String, fileName: String) {
        activity.runOnUiThread {
            try {
                if (!checkPermissions()) {
                    requestPermissions()
                    Toast.makeText(activity, "يرجى منح صلاحية التخزين ثم حاول مرة أخرى", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }

                var cleanBase64 = base64Data
                if (base64Data.contains(",")) {
                    cleanBase64 = base64Data.substring(base64Data.indexOf(",") + 1)
                }

                val imageBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)

                if (bitmap == null) {
                    Toast.makeText(activity, "❌ تعذر تحويل الصورة", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }

                val finalFileName = if (fileName.isEmpty()) {
                    generateFileName()
                } else {
                    if (!fileName.endsWith(".png", ignoreCase = true)) "$fileName.png" else fileName
                }

                val savedUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveImageAndroid10AndAbove(bitmap, finalFileName)
                } else {
                    saveImageLegacy(bitmap, finalFileName)
                }

                if (savedUri != null) {
                    val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, savedUri)
                    activity.sendBroadcast(mediaScanIntent)
                    Toast.makeText(activity, "✅ تم حفظ الصورة في المعرض", Toast.LENGTH_LONG).show()
                    openGallery(savedUri)
                } else {
                    Toast.makeText(activity, "❌ فشل حفظ الصورة", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(activity, "❌ خطأ في حفظ الصورة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    @JavascriptInterface
    fun saveToGallery(base64Data: String) {
        saveImage(base64Data, "")
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun onPageLoaded() {}

    private fun checkPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            true
        } else {
            val writePermission = ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            val readPermission = ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            writePermission && readPermission
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun generateFileName(): String {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return "ProEdit_${timeStamp}.png"
    }

    @SuppressLint("MissingPermission")
    private fun saveImageLegacy(bitmap: Bitmap, fileName: String): Uri? {
        return try {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val appDir = File(picturesDir, "HTMLSmart")
            if (!appDir.exists()) appDir.mkdirs()

            val imageFile = File(appDir, fileName)
            FileOutputStream(imageFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, IMAGE_QUALITY, fos)
            }

            @Suppress("DEPRECATION")
            MediaStore.Images.Media.insertImage(activity.contentResolver, imageFile.absolutePath, fileName, "Created by HTML Smart")
            Uri.fromFile(imageFile)
        } catch (_: Exception) {
            null
        }
    }

    private fun saveImageAndroid10AndAbove(bitmap: Bitmap, fileName: String): Uri? {
        val resolver = activity.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HTMLSmart")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        return try {
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                resolver.openOutputStream(it)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, IMAGE_QUALITY, outputStream)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
                uri
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun openGallery(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "image/*")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(intent)
        } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun shareImage(base64Data: String, fileName: String) {
        activity.runOnUiThread {
            try {
                val cleanBase64 = if (base64Data.contains(",")) base64Data.substring(base64Data.indexOf(",") + 1) else base64Data
                val imageBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size) ?: return@runOnUiThread

                val tempFile = File.createTempFile("share_", ".png", activity.cacheDir)
                FileOutputStream(tempFile).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

                val shareIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_STREAM, Uri.fromFile(tempFile))
                    type = "image/png"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                activity.startActivity(Intent.createChooser(shareIntent, "مشاركة الصورة عبر:"))
            } catch (_: Exception) {
                Toast.makeText(activity, "❌ خطأ في مشاركة الصورة", Toast.LENGTH_SHORT).show()
            }
        }
    }
}