package com.hussain.htmlsmart

data class HTMLPage(
    val id: Long,
    val title: String,
    val html: String,
    val css: String = "",
    val js: String = "",
    val iconUri: String = ""
)