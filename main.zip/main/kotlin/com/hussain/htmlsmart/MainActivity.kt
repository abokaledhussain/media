package com.hussain.htmlsmart

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var webView: AdvancedWebView
    private lateinit var welcomeLayout: LinearLayout
    private lateinit var pagesRecyclerView: RecyclerView
    private lateinit var searchEditText: EditText
    private lateinit var toolbar: Toolbar
    private val pages = mutableListOf<HTMLPage>()
    private lateinit var adapter: PagesAdapter
    private val gson = Gson()
    private val PAGES_FILE = "pages_data.json"

    private var fullscreenContainer: FrameLayout? = null
    private var selectedIconUri: String = ""
    private var currentDialogPreviewImg: ImageView? = null
    private var gridColumnCount = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupToolbar()
        setupViews()
        setupNavigationView()

        val webInterface = WebAppInterface(this)
        webView.addJavascriptInterface(webInterface, "AndroidApp")
        webView.addJavascriptInterface(webInterface, "Android")

        // DownloadListener لالتقاط وتنزيل الملفات (مثل ePub والـ ZIP) وحفظها بالتنزيلات مباشرة
        webView.setDownloadListener { url, _, _, mimetype, _ ->
            if (url.startsWith("data:")) {
                try {
                    val base64Data = url.substringAfter(",")
                    val cleanMimeType = mimetype ?: "application/octet-stream"
                    val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)

                    val fileName = when {
                        cleanMimeType.contains("epub") -> "clean_edited_book.epub"
                        cleanMimeType.contains("pdf") -> "document.pdf"
                        cleanMimeType.contains("zip") -> "archive.zip"
                        else -> "downloaded_file.bin"
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val resolver = contentResolver
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(MediaStore.MediaColumns.MIME_TYPE, cleanMimeType)
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            resolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(decodedBytes)
                            }
                            Toast.makeText(this, "✅ تم حفظ الملف في التنزيلات: $fileName", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        if (!downloadsDir.exists()) downloadsDir.mkdirs()
                        val file = File(downloadsDir, fileName)
                        FileOutputStream(file).use { it.write(decodedBytes) }
                        Toast.makeText(this, "✅ تم حفظ الملف في التنزيلات", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "❌ خطأ في التحميل: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null) return false

                if (url.lowercase().endsWith(".pdf")) {
                    val fileName = url.substringAfterLast("/")
                    openPdfFromAssets(fileName)
                    return true
                }

                if (url.contains("youtube.com") || url.contains("youtu.be")) {
                    return false
                }

                return false
            }
        }

        loadPages()
        showWelcomeScreen()
        checkPermissions()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (drawerLayout.isDrawerOpen(navigationView)) {
                drawerLayout.closeDrawer(navigationView)
                return true
            } else if (fullscreenContainer != null) {
                webView.webChromeClient?.onHideCustomView()
                return true
            } else if (webView.visibility == View.VISIBLE) {
                showWelcomeScreen()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    fun toggleFullscreen(enabled: Boolean, view: View?) {
        val decorView = window.decorView as FrameLayout
        if (enabled) {
            supportActionBar?.hide()
            webView.visibility = View.GONE

            fullscreenContainer = FrameLayout(this).apply {
                setBackgroundColor(Color.BLACK)
                addView(view)
            }
            decorView.addView(
                fullscreenContainer,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )

            hideSystemBars()
        } else {
            supportActionBar?.show()
            webView.visibility = View.VISIBLE
            decorView.removeView(fullscreenContainer)
            fullscreenContainer = null
            showSystemBars()
        }
    }

    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
            window.insetsController?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private fun showSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.show(WindowInsets.Type.statusBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    private fun setupToolbar() {
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val drawable = androidx.appcompat.graphics.drawable.DrawerArrowDrawable(this)
        drawable.color = Color.WHITE
        drawable.progress = 0f
        toolbar.navigationIcon = drawable
        toolbar.setNavigationOnClickListener { drawerLayout.openDrawer(navigationView) }
    }

    private fun setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.nav_view)
        webView = findViewById(R.id.web_view)
        welcomeLayout = findViewById(R.id.welcome_layout)
        pagesRecyclerView = findViewById(R.id.pages_recycler_view)
        searchEditText = findViewById(R.id.edit_search)

        adapter = PagesAdapter(pages, { showPage(it) }, { showPageOptions(it) })
        pagesRecyclerView.layoutManager = GridLayoutManager(this, gridColumnCount)
        pagesRecyclerView.adapter = adapter

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s.toString().trim())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupNavigationView() {
        navigationView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.nav_home -> showWelcomeScreen()
                R.id.nav_new -> showAddPageDialog()
                R.id.nav_grid_columns -> showGridColumnCountDialog()
                R.id.nav_backup -> backupAllPages()
                R.id.nav_restore_all -> triggerRestoreAll()
            }
            drawerLayout.closeDrawers()
            true
        }
    }

    fun showGridColumnCountDialog() {
        val options = arrayOf("2 أعمدة", "3 أعمدة (افتراضي)", "4 أعمدة", "5 أعمدة")
        val dialog = AlertDialog.Builder(this)
            .setTitle("اختر عدد الأعمدة")
            .setItems(options) { _, which ->
                gridColumnCount = when (which) {
                    0 -> 2
                    1 -> 3
                    2 -> 4
                    3 -> 5
                    else -> 3
                }
                (pagesRecyclerView.layoutManager as? GridLayoutManager)?.spanCount = gridColumnCount
                adapter.notifyDataSetChanged()
            }
            .create()

        dialog.show()
        dialog.window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
    }

    fun showPage(page: HTMLPage) {
        webView.visibility = View.VISIBLE
        welcomeLayout.visibility = View.GONE
        supportActionBar?.hide()
        hideSystemBars()

        val fullHtml = """
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    body { margin: 0; padding: 0; font-family: sans-serif; line-height: 1.6; color: #333; }
                    img { max-width: 100%; height: auto; border-radius: 8px; display: block; margin: 10px auto; }
                    ${page.css}
                </style>
            </head>
            <body>
                ${page.html}
                <script>${page.js}</script>
            </body>
            </html>
        """.trimIndent()

        webView.loadHtmlContent(fullHtml)
        webView.clearHistory()
    }

    fun printCurrentPage() {
        val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val printAdapter = webView.createPrintDocumentAdapter("HTML_Smart_Doc")
        val printAttributes = PrintAttributes.Builder().build()
        printManager.print("Print_Job", printAdapter, printAttributes)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1001) {
            if (webView.filePathCallback == null) return
            if (resultCode == RESULT_OK && data != null) {
                var results: Array<Uri>? = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                if (results == null && data.data != null) {
                    results = arrayOf(data.data!!)
                }
                webView.filePathCallback?.onReceiveValue(results)
            } else {
                webView.filePathCallback?.onReceiveValue(null)
            }
            webView.filePathCallback = null
            return
        }

        if (resultCode != RESULT_OK) return

        when (requestCode) {
            2002 -> {
                data?.data?.let { uri ->
                    try {
                        val jsonString = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        val type = object : TypeToken<MutableList<HTMLPage>>() {}.type
                        val restoredPages: MutableList<HTMLPage>? = gson.fromJson(jsonString, type)

                        if (!restoredPages.isNullOrEmpty()) {
                            pages.clear()
                            pages.addAll(restoredPages)
                            savePages()
                            adapter.updateList(pages)
                            Toast.makeText(this, "تم استعادة ${restoredPages.size} صفحة ✅", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "خطأ في الاستعادة", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            3003 -> {
                data?.data?.let { uri ->
                    try {
                        val jsonString = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        jsonString?.let {
                            val escapedJson = it.replace("'", "\\'").replace("\n", "")
                            webView.post {
                                webView.loadUrl("javascript:processImportedData('$escapedJson')")
                            }
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "خطأ في قراءة الملف", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            4004 -> {
                data?.data?.let { treeUri ->
                    try {
                        contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        val fileList = mutableListOf<String>()
                        val rootDoc = DocumentFile.fromTreeUri(this, treeUri)

                        fun walkDir(dir: DocumentFile, currentPath: String) {
                            dir.listFiles().forEach { file ->
                                if (file.isDirectory) {
                                    walkDir(file, "$currentPath${file.name}/")
                                } else {
                                    fileList.add("$currentPath${file.name}")
                                }
                            }
                        }
                        rootDoc?.let { walkDir(it, "${it.name}/") }
                        val jsonPaths = gson.toJson(fileList)
                        webView.post {
                            webView.evaluateJavascript("receiveFolderStructure('$jsonPaths')", null)
                        }
                        Toast.makeText(this, "تم جلب ${fileList.size} مسار بنجاح ✅", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "خطأ في المجلد: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            5005 -> {
                data?.data?.let { uri ->
                    try {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: Exception) {}
                    selectedIconUri = uri.toString()
                    try {
                        currentDialogPreviewImg?.setImageURI(uri)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 100)
        }
    }

    private fun savePages() {
        try {
            File(filesDir, PAGES_FILE).writeText(gson.toJson(pages))
        } catch (_: Exception) {}
    }

    private fun loadPages() {
        try {
            val file = File(filesDir, PAGES_FILE)
            if (file.exists()) {
                val type = object : TypeToken<List<HTMLPage>>() {}.type
                pages.clear()
                val loaded: List<HTMLPage>? = gson.fromJson(file.readText(), type)
                if (loaded != null) {
                    pages.addAll(loaded)
                }
                adapter.updateList(pages)
            }
        } catch (_: Exception) {}
    }

    private fun showWelcomeScreen() {
        webView.visibility = View.GONE
        welcomeLayout.visibility = View.VISIBLE
        supportActionBar?.show()
        showSystemBars()
        supportActionBar?.title = "HTML Smart"
        webView.loadUrl("about:blank")
        webView.clearHistory()
    }

    private fun showAddPageDialog(existing: HTMLPage? = null) {
        val view = layoutInflater.inflate(R.layout.dialog_add_page, null)
        val titleEt = view.findViewById<EditText>(R.id.edit_text_title)
        val htmlEt = view.findViewById<EditText>(R.id.edit_text_html)
        val cssEt = view.findViewById<EditText>(R.id.edit_text_css)
        val jsEt = view.findViewById<EditText>(R.id.edit_text_js)
        val imgPreview = view.findViewById<ImageView>(R.id.img_preview)
        val btnSelectIcon = view.findViewById<Button>(R.id.btn_select_icon)

        currentDialogPreviewImg = imgPreview
        selectedIconUri = existing?.iconUri ?: ""

        if (selectedIconUri.isNotEmpty()) {
            try {
                imgPreview.setImageURI(Uri.parse(selectedIconUri))
            } catch (_: Exception) {}
        }

        // تم تعديل زر اختيار الصورة ليفتح استوديو الصور ومعرض الجهاز مباشرة دون الدخول للمجلدات
        btnSelectIcon.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                type = "image/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 5005)
        }

        existing?.let {
            titleEt.setText(it.title)
            htmlEt.setText(it.html)
            cssEt.setText(it.css)
            jsEt.setText(it.js)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة صفحة" else "تعديل")
            .setView(view)
            .setPositiveButton("حفظ") { _, _ ->
                val page = HTMLPage(
                    id = existing?.id ?: System.currentTimeMillis(),
                    title = titleEt.text.toString(),
                    html = htmlEt.text.toString(),
                    css = cssEt.text.toString(),
                    js = jsEt.text.toString(),
                    iconUri = selectedIconUri
                )
                if (existing != null) {
                    val idx = pages.indexOfFirst { it.id == existing.id }
                    if (idx != -1) pages[idx] = page
                } else {
                    pages.add(page)
                }
                savePages()
                adapter.updateList(pages)
            }
            .setNegativeButton("إلغاء", null)
            .create()

        dialog.show()
        dialog.window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
    }

    private fun backupAllPages() {
        try {
            if (pages.isEmpty()) return
            val jsonContent = gson.toJson(pages)
            val fileName = "Backup_${System.currentTimeMillis()}.json"
            val webInterface = WebAppInterface(this)
            webInterface.saveFile(jsonContent, fileName)
        } catch (_: Exception) {}
    }

    private fun triggerRestoreAll() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "اختر ملف النسخة الاحتياطية"), 2002)
    }

    private fun showPageOptions(page: HTMLPage) {
        val dialog = AlertDialog.Builder(this)
            .setItems(arrayOf("فتح", "تعديل", "حذف")) { _, i ->
                when (i) {
                    0 -> showPage(page)
                    1 -> showAddPageDialog(page)
                    2 -> {
                        pages.remove(page)
                        savePages()
                        adapter.updateList(pages)
                        showWelcomeScreen()
                    }
                }
            }
            .create()

        dialog.show()
        dialog.window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
    }

    private fun openPdfFromAssets(fileName: String) {
        try {
            val inputStream = assets.open("pdf/$fileName")
            val outFile = File(cacheDir, fileName)
            inputStream.use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
            val uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                outFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            }
            startActivity(Intent.createChooser(intent, "افتح القصة بواسطة:"))
        } catch (e: Exception) {
            Toast.makeText(this, "تأكد من وجود الملف في assets/pdf/", Toast.LENGTH_LONG).show()
        }
    }
}